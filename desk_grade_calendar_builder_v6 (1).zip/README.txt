Desk-Grade Commodity Calendar Builder V6

V6 is the corrected version after confirming:
Pen dates are always the business day before expiration / last day.

How V6 works:
1. You enter official last-day / expiration dates.
2. V6 auto-generates:
   - Pen CL
   - Pen NG
   - Pen RB & HO
   - Pen Brent
3. V6 blocks manual Pen labels in either Official Inputs or Desk Overlay.
4. V6 still keeps desk overlays separate for gasoil, TAS, crypto, notice dates, softs, grains, metals, etc.
5. DB/GSCI/WASDE can be auto-generated, but should still be reviewed monthly.

Important:
- Do not put Pen labels in the JSON.
- Enter the official last day only.
- Let the tool derive Pen dates.
- If your manual calendar shows Pen on the same date as the last day, review the label. That is usually a mislabeled last day.

How to use:
- Open desk_grade_calendar_builder_v6.html in Chrome or Edge.
- Start with April Sample or May Sample.
- Replace official dates for the new month.
- Add desk-specific reminders in Desk Overlay.
- Review QA.
- Print / Save PDF or Download CSV.
